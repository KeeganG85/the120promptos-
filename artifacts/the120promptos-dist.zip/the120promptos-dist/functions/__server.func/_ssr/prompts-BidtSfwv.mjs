//#region node_modules/.nitro/vite/services/ssr/assets/prompts-BidtSfwv.js
var prompts = [
	{
		id: "avatar",
		category: "foundations",
		title: "Ideal Customer Avatar Builder",
		role: "positioning strategist",
		purpose: "Build a specific, local, behaviour-true picture of who actually buys — not a generic persona.",
		task: "Create a practical customer avatar. Include what they run or do, where they live/work in South Africa, the trigger that makes them search, what they type into Google or send on WhatsApp, objections, the conversion action they will actually take, and where competitors speak too broadly.",
		expected: "A one-page avatar: snapshot, jobs-to-be-done, search phrases (including near-me), WhatsApp-first behaviour, objections, and 5 message angles.",
		featured: true
	},
	{
		id: "gap",
		category: "foundations",
		title: "Competitor Gap Analysis",
		role: "competitive analyst",
		purpose: "Find the gap an owner-run business can actually occupy — not a fantasy category.",
		task: "Compare this business against 4 named local competitors. Map claims, offers, proof, response speed, and Google Business Profile quality. Name the gap that is true, defensible, and useful in rands.",
		expected: "A gap map, 3 claims to stop making, 3 claims to own, and a 90-day differentiation plan.",
		featured: true
	},
	{
		id: "positioning",
		category: "foundations",
		title: "Positioning Statement Builder",
		role: "brand strategist",
		purpose: "Write a positioning line a staff member could repeat on a call.",
		task: "Draft 5 positioning statements using: for [who] in [place] who [struggle], we [offer] so they [outcome], unlike [alternative]. Kill cleverness. Keep it South African and specific.",
		expected: "5 options, a recommended line, and a 40-word about-us paragraph."
	},
	{
		id: "niche",
		category: "foundations",
		title: "Niche Tightener",
		role: "focus coach",
		purpose: "Stop serving everyone in Gauteng. Name a tighter, richer niche.",
		task: "Propose 3 tighter niches from the current client list and search demand. For each: who, where, job-to-be-done, offer, and why the owner can win without a big team.",
		expected: "3 niche options scored on fit, demand, and delivery — plus a recommended pick."
	},
	{
		id: "jtb",
		category: "foundations",
		title: "Jobs-To-Be-Done Interview",
		role: "customer researcher",
		purpose: "Get past demographics into the job the customer is hiring the business to do.",
		task: "Write a 12-question interview (in-person or WhatsApp) that surfaces the trigger, failed alternatives, social pressure, and the progress they want. Include how to ask without sounding like a survey.",
		expected: "Interview script, note-taking sheet, and a synthesis template."
	},
	{
		id: "vpc",
		category: "foundations",
		title: "Value Proposition Canvas",
		role: "offer designer",
		purpose: "Match pains, gains and jobs to a real offer — in language the market uses.",
		task: "Fill a value proposition canvas for this business using South African phrasing. Translate it into a homepage hero and a WhatsApp one-liner.",
		expected: "Canvas in prose, hero copy, WhatsApp one-liner, and 3 proof points still needed."
	},
	{
		id: "category-design",
		category: "foundations",
		title: "Category Design Prompt",
		role: "category designer",
		purpose: "Decide whether to compete in an existing category or name a clearer one.",
		task: "Test if this business is in a crowded category. If a new frame helps buyers understand it faster, propose one that a Sandton accountant or a Pretoria contractor would actually say out loud.",
		expected: "Stay-vs-reframe recommendation, a category sentence, and phrases to retire."
	},
	{
		id: "origin",
		category: "foundations",
		title: "Origin Story Narrative",
		role: "narrative strategist",
		purpose: "Turn the founder story into a trust asset, not a biography.",
		task: "Write a 220-word origin story for the website About page: the problem noticed in South Africa, the failed status quo, the decision to build this, and the standard the owner holds. No heroics.",
		expected: "About-page story, 40-word short version, and a 2-line WhatsApp intro."
	},
	{
		id: "voice",
		category: "foundations",
		title: "Brand Voice Guardrails",
		role: "brand voice director",
		purpose: "Give AI (and staff) a voice they can actually write in.",
		task: "Define voice: 5 we-say / we-don't-say pairs, reading level, words that sound imported and should be banned, and how to write for WhatsApp vs the website.",
		expected: "A one-page voice guide AI can follow on every future prompt."
	},
	{
		id: "offer-arch",
		category: "foundations",
		title: "Offer Architecture Map",
		role: "commercial designer",
		purpose: "See the ladder from first job to flagship offer.",
		task: "Map entry, core, and premium offers in rands. Show who each is for, the next step, and where the business currently dumps everyone into one package.",
		expected: "Offer ladder, recommended packaging, and what to stop selling as a custom job."
	},
	{
		id: "pricing-phil",
		category: "foundations",
		title: "Pricing Philosophy",
		role: "pricing strategist",
		purpose: "Replace gut-feel discounts with a philosophy the owner can defend.",
		task: "Draft a pricing philosophy: value basis, when to discount, when not to, how to talk rands without apology, and a response to “your competitor is cheaper”.",
		expected: "Philosophy memo, 3 talk tracks, and a discount policy of 6 lines."
	},
	{
		id: "model-stress",
		category: "foundations",
		title: "Business Model Stress Test",
		role: "operator",
		purpose: "See where the model breaks if the owner gets sick for two weeks.",
		task: "Stress-test the model: concentration of clients, cash timing, delivery dependence on the founder, and WhatsApp as a single point of failure. Propose 5 resilience moves.",
		expected: "Risks ranked, founder-dependence score, and 5 moves for the next 30 days."
	},
	{
		id: "one-pager",
		category: "foundations",
		title: "One-Page Strategy Memo",
		role: "chief of staff",
		purpose: "Put the whole business on one page the owner can revisit on Monday.",
		task: "Write a one-page strategy: who we serve, where, offer, proof, 90-day bets, what we will not do, and the weekly cadence. Plain language.",
		expected: "A one-page memo ready to print and pin."
	},
	{
		id: "founder-time",
		category: "foundations",
		title: "Founder Time Audit for Positioning",
		role: "operator coach",
		purpose: "See whether the calendar matches the positioning the owner claims.",
		task: "From a typical week, map time to: delivery, sales, admin, marketing, rest. Show the mismatch with the stated strategy and the 3 calendar moves that would make positioning real.",
		expected: "Time map, mismatch diagnosis, 3 calendar changes."
	},
	{
		id: "seo-map",
		category: "visibility",
		title: "SEO Keyword Opportunity Map",
		role: "SEO strategist",
		purpose: "Find South African search demand the business can honestly serve.",
		task: "Propose topic clusters around the offer and location. Include head terms, long-tail, near-me, and questions. Do not invent volumes. Flag what needs Search Console / GBP data the owner must paste in.",
		expected: "Cluster map, 15 page opportunities, and a 90-day publishing order.",
		featured: true
	},
	{
		id: "gbp",
		category: "visibility",
		title: "Google Business Profile Optimiser",
		role: "local SEO specialist",
		purpose: "Turn GBP into a working shopfront, not a neglected listing.",
		task: "Audit and rewrite GBP: categories, services, description, Q&A, photo plan, review reply templates, and weekly posting. South African NAP consistency.",
		expected: "GBP checklist, rewritten description, 8 post ideas, 6 review replies."
	},
	{
		id: "near-me",
		category: "visibility",
		title: "Near Me Visibility Plan",
		role: "local SEO specialist",
		purpose: "Win the searches that happen with a suburb or “near me” attached.",
		task: "Build a local visibility plan for the named suburbs this business can actually serve. Pages, GBP, citations to treat carefully, and what not to spam.",
		expected: "Suburb plan, on-page local brief, and a do-not-spam list."
	},
	{
		id: "pillars",
		category: "visibility",
		title: "Content Pillar System",
		role: "content strategist",
		purpose: "Stop random posts. Install 4 pillars that compound.",
		task: "Propose 4 content pillars tied to search, sales conversations, and WhatsApp questions. Show 3 pieces under each and which channel they live on.",
		expected: "Pillar map, 12-piece starter list, and a monthly cadence."
	},
	{
		id: "engine",
		category: "visibility",
		title: "Weekly Content Engine",
		role: "content operations lead",
		purpose: "A realistic weekly engine for an owner who still delivers the work.",
		task: "Design a 90-minute weekly content engine: capture, draft with AI, review, publish, and reply. Include a WhatsApp note-to-self workflow.",
		expected: "Weekly ritual, tools, and a one-week example calendar."
	},
	{
		id: "linkedin",
		category: "visibility",
		title: "LinkedIn Authority Cadence",
		role: "LinkedIn strategist",
		purpose: "Use LinkedIn as a professional trust channel, not a ghost town.",
		task: "Build a 4-week LinkedIn cadence for a South African professional or agency owner. Hooks, proof, point of view, and what never to post.",
		expected: "16 post prompts, profile rewrite notes, and engagement rules."
	},
	{
		id: "newsletter",
		category: "visibility",
		title: "Newsletter Welcome Sequence",
		role: "email strategist",
		purpose: "A POPIA-aware welcome that teaches and earns the next click.",
		task: "Write a 4-email welcome sequence: why they joined, a useful job-to-be-done, proof, and a single ask. Include consent language and unsubscribe reality.",
		expected: "4 emails, subject lines, and a consent footnote."
	},
	{
		id: "shortform",
		category: "visibility",
		title: "Short-Form Script System",
		role: "content director",
		purpose: "Turn one idea into Reels / Shorts / TikTok without dancing.",
		task: "Create a script system for talking-head or overlay videos a trades or professional business would not be embarrassed by. 8 scripts from one pillar.",
		expected: "Script template + 8 ready scripts with on-screen text."
	},
	{
		id: "community",
		category: "visibility",
		title: "Community Building Playbook",
		role: "community strategist",
		purpose: "Decide if a community is real leverage or unpaid babysitting.",
		task: "Recommend whether this business should run a WhatsApp group, a monthly breakfast, or nothing. If yes, design the purpose, rules, and owner time budget.",
		expected: "Go/no-go, format, 30-day standup plan, and risk notes (POPIA, spam)."
	},
	{
		id: "pr",
		category: "visibility",
		title: "Local Media Pitch",
		role: "PR lead",
		purpose: "Earn a local story without a PR firm.",
		task: "Draft 3 pitch angles for local or trade press in South Africa. Include why it is news, not an advert, and a 120-word pitch email.",
		expected: "3 angles, 1 recommended, pitch email, and a quote the owner can stand behind."
	},
	{
		id: "reviews",
		category: "visibility",
		title: "Review Generation System",
		role: "reputation operator",
		purpose: "Ask for reviews the consented, non-awkward way.",
		task: "Design a review request system for Google (and where relevant industry boards). Timing, WhatsApp wording, who not to ask, and how to reply.",
		expected: "SOP, 4 message variants, reply pack, and a “never incentivise fake reviews” rule."
	},
	{
		id: "aeo",
		category: "visibility",
		title: "AI Visibility Entity Pack",
		role: "AEO / GEO specialist",
		purpose: "Make the business easier for answer engines to describe accurately.",
		task: "Build an entity pack: official name, NAP, services, geo, sameAs candidates, FAQs, and a 80-word machine-clear description. No claims of guaranteed citations.",
		expected: "Entity sheet, FAQ set, and on-page placement notes."
	},
	{
		id: "linking",
		category: "visibility",
		title: "Internal Linking Architecture",
		role: "SEO architect",
		purpose: "Connect service, location and proof pages so neither humans nor crawlers get lost.",
		task: "Propose an internal linking map for a small South African service site of 8–20 URLs. Include anchor suggestions that sound human.",
		expected: "Link map, orphan risks, and a 1-hour implementation list."
	},
	{
		id: "clusters",
		category: "visibility",
		title: "Topic Cluster Builder",
		role: "content SEO lead",
		purpose: "Turn one money page into a cluster that can rank and convert.",
		task: "Pick the primary money page and design a cluster: pillar, 6 supporting articles, FAQs, and internal links. Localise to the city.",
		expected: "Cluster outline with titles, intent, and internal link notes."
	},
	{
		id: "validate",
		category: "offers",
		title: "Offer Validation Interview",
		role: "product researcher",
		purpose: "Test an offer with conversations before building a whole funnel.",
		task: "Write a validation script for 8 conversations (call or WhatsApp). Distinguish polite interest from willingness to pay in rands. Include kill-criteria.",
		expected: "Script, scorecard, and a go / iterate / kill rule."
	},
	{
		id: "packages",
		category: "offers",
		title: "Good / Better / Best Package Builder",
		role: "packaging strategist",
		purpose: "Replace one shapeless quote with three clear packages.",
		task: "Design three packages in rands. Make the middle the honest recommendation. Include what is not in each, delivery time, and a comparison table in prose.",
		expected: "Three packages, names, inclusions, and a recommendation line."
	},
	{
		id: "workshop",
		category: "offers",
		title: "Workshop Outline",
		role: "curriculum designer",
		purpose: "Turn expertise into a half-day workshop a local room would pay for.",
		task: "Outline a 3.5-hour workshop: promise, modules, exercises, materials, and a follow-on offer. Price band in rands with rationale — not a guarantee.",
		expected: "Run-of-show, slide list, workbook notes, and follow-on offer."
	},
	{
		id: "course",
		category: "offers",
		title: "Course Curriculum Architect",
		role: "course designer",
		purpose: "See if a course is justified — then structure it if it is.",
		task: "Decide course vs service vs workshop. If a course: 6-module curriculum, outcomes, and what must stay as a done-for-you service.",
		expected: "Format decision, curriculum, and a “do not course-ify this” list."
	},
	{
		id: "membership",
		category: "offers",
		title: "Membership Offer Design",
		role: "membership designer",
		purpose: "Design a retainer or membership that is not just unpaid Slack.",
		task: "Design a monthly membership: who it's for, cadence, deliverables, WhatsApp rules, and cancellation. Price in rands as a hypothesis.",
		expected: "Membership one-pager, onboarding, and a boundary list."
	},
	{
		id: "ebook-pos",
		category: "offers",
		title: "Ebook Positioning",
		role: "product marketer",
		purpose: "Position a digital product so it is a tool, not a PDF graveyard.",
		task: "Position an ebook or prompt library: who, job-to-be-done, transformation in operating terms (not income claims), and the sales-page promise that stays honest.",
		expected: "Positioning, title options, and a promise/non-promise list."
	},
	{
		id: "launch",
		category: "offers",
		title: "Launch Sequence Planner",
		role: "launch strategist",
		purpose: "A small, honest launch an owner can run without a 30-person team.",
		task: "Plan a 14-day launch: audience already owned, content, email, WhatsApp broadcast rules (consented lists only), and a cart / access moment. No fake scarcity.",
		expected: "Day-by-day plan, assets list, and a no-fake-scarcity policy."
	},
	{
		id: "bundle",
		category: "offers",
		title: "Irresistible Bundle Builder",
		role: "offer designer",
		purpose: "Bundle only what increases completion, not cart padding.",
		task: "Propose a bundle around the core offer. Each component must have a job. Price the bundle in rands vs buying apart. Kill anything decorative.",
		expected: "Bundle card, jobs of each piece, and a pricing hypothesis."
	},
	{
		id: "guarantee",
		category: "offers",
		title: "Guarantee / Risk Reversal",
		role: "conversion strategist",
		purpose: "Write a guarantee the owner can honour in South African consumer law reality.",
		task: "Draft 2 guarantee options the business can operationally honour. Include exclusions, how to claim, and what would be reckless to promise.",
		expected: "Recommended guarantee, policy text, and a “never promise this” list."
	},
	{
		id: "pricing-page",
		category: "offers",
		title: "Pricing Page Narrative",
		role: "conversion copywriter",
		purpose: "Explain rands in a way that reduces back-and-forth quoting.",
		task: "Write pricing-page copy: who each option is for, what's included, the next step, and FAQs about payment (EFT, cards) without inventing fees.",
		expected: "Full pricing section copy and 6 FAQs."
	},
	{
		id: "menu",
		category: "offers",
		title: "Service Menu Rewrite",
		role: "offer copywriter",
		purpose: "Rewrite the service list so a first-time visitor knows what to buy.",
		task: "Turn a messy service list into a clear menu with names, jobs, starting-from language (if honest), and a primary CTA per item.",
		expected: "Rewritten menu of 4–7 items and a recommended default."
	},
	{
		id: "retainer",
		category: "offers",
		title: "Retainers vs Projects",
		role: "agency operator",
		purpose: "Choose the commercial shape that matches delivery capacity.",
		task: "Compare project, retainer, and productised service for this business. Recommend one primary shape and the contract clauses the owner should actually understand.",
		expected: "Recommendation, sample scope outline, and red-flag clauses in plain language."
	},
	{
		id: "productised",
		category: "offers",
		title: "Productised Service Blueprint",
		role: "operations designer",
		purpose: "Turn a custom job into a named, repeatable service.",
		task: "Productise one service: name, scope, timeline, inputs from the client, WhatsApp kickoff, and what happens if they stall. Price band in rands as a hypothesis.",
		expected: "One-pager, kickoff SOP, and a scope-creep script."
	},
	{
		id: "sales-page",
		category: "conversion",
		title: "Sales Page Architecture",
		role: "direct-response strategist",
		purpose: "Structure a long-form sales page without American hype.",
		task: "Architect a sales page: sections, proof required, objections, CTA, and what to delete. Tone: serious South African operator, not a guru.",
		expected: "Section map, required proof list, and CTA variants."
	},
	{
		id: "landing",
		category: "conversion",
		title: "Landing Page Copy Writer",
		role: "landing page copywriter",
		purpose: "Write a landing page that asks for one action.",
		task: "Write landing copy: eyebrow, headline, supporting, proof, offer, FAQ, final CTA. One action only. WhatsApp or form — choose based on the business. No fake countdown.",
		expected: "Full landing copy in labelled sections, plus meta title and description.",
		featured: true
	},
	{
		id: "wa-scripts",
		category: "conversion",
		title: "WhatsApp First-Response Scripts",
		role: "sales operator",
		purpose: "Answer the first WhatsApp like a professional front desk.",
		task: "Write 6 first-response scripts: after-hours, price-check, “are you available Monday”, complaint, spam, and booked-next-step. Keep them human, short, and POPIA-aware.",
		expected: "6 scripts, a 4-line house style, and a handoff to calendar or EFT."
	},
	{
		id: "funnel",
		category: "conversion",
		title: "Funnel Blueprint Designer",
		role: "funnel strategist",
		purpose: "Draw a funnel that matches how South African buyers actually move.",
		task: "Design a simple funnel: attention → trust → conversation (often WhatsApp) → booked next step → delivery → review. Name the assets at each stage. No 12-step software fantasy.",
		expected: "Funnel diagram in prose, assets list, and metrics per stage.",
		featured: true
	},
	{
		id: "cta-audit",
		category: "conversion",
		title: "CTA Clarity Audit",
		role: "conversion editor",
		purpose: "Make every page ask for one obvious next step.",
		task: "Audit typical CTAs on a service site. Rewrite 8 CTAs so they name the action (WhatsApp, call, book, download). Kill “submit” and “learn more” unless they are true.",
		expected: "Before/after CTA table and placement notes."
	},
	{
		id: "objections",
		category: "conversion",
		title: "Objection Handling Library",
		role: "sales coach",
		purpose: "Answer the real objections without becoming a haggler.",
		task: "Build an objection library: price, timing, “I need to think”, competitor, “send a proposal”. Written for call and WhatsApp. Honest, not slick.",
		expected: "8 objections with responses and a when-to-walk-away line."
	},
	{
		id: "testimonials",
		category: "conversion",
		title: "Testimonial Request + Edit",
		role: "proof producer",
		purpose: "Collect usable proof without putting words in a client’s mouth.",
		task: "Write a request (email + WhatsApp), 6 interview questions (Before / Use / After), and an editing method that keeps their voice and gets written approval.",
		expected: "Request copy, questions, edit checklist, and approval message."
	},
	{
		id: "case-study",
		category: "conversion",
		title: "Case Study Interview",
		role: "case study writer",
		purpose: "Capture a case study that is operationally specific, not a vanity quote.",
		task: "Interview + write a case study: situation, constraint, work done, result the client will verify, and what is not claimed. No invented percentages.",
		expected: "Interview guide and a 400-word case study template filled with placeholders the owner must verify."
	},
	{
		id: "price-talk",
		category: "conversion",
		title: "Pricing Conversation Guide",
		role: "sales lead",
		purpose: "Talk rands on a call without flinching or over-explaining.",
		task: "Write a 12-minute pricing conversation: frame, number, silence, questions, next step. Include a script for “that’s too much”.",
		expected: "Call outline, word-for-word moments, and a follow-up WhatsApp."
	},
	{
		id: "discovery",
		category: "conversion",
		title: "Discovery Call Agenda",
		role: "sales operator",
		purpose: "Run a discovery call that diagnoses, not pitches for 40 minutes.",
		task: "Design a 25-minute discovery: agenda, questions, note sheet, disqualify rules, and the close to a proposal or a no.",
		expected: "Agenda, question list, and a post-call summary template."
	},
	{
		id: "followup",
		category: "conversion",
		title: "Seven-Day Follow-up Sequence",
		role: "pipeline operator",
		purpose: "Follow up like a professional, not a pest.",
		task: "Write a 7-day follow-up for a quoted but silent lead: WhatsApp + email, spacing, value in each touch, and a clean close-the-file message.",
		expected: "Day-by-day messages and a CRM note template."
	},
	{
		id: "upsell",
		category: "conversion",
		title: "Upsell / Cross-sell Map",
		role: "commercial designer",
		purpose: "Offer the next useful thing, not a random add-on.",
		task: "Map natural next offers after delivery. Timing, script, and what would feel extractive. Price in rands as a hypothesis.",
		expected: "Map, 3 scripts, and a “do not upsell this” list."
	},
	{
		id: "recovery",
		category: "conversion",
		title: "Abandoned Enquiry Recovery",
		role: "conversion operator",
		purpose: "Recover the WhatsApp that went quiet without guilt-tripping.",
		task: "Design a 3-touch recovery for enquiries that stalled: timing, copy, and when to stop. POPIA-aware, no bought lists.",
		expected: "3 messages, timing rules, and a stop rule."
	},
	{
		id: "proposal",
		category: "conversion",
		title: "Proposal / Quote Narrative",
		role: "proposal writer",
		purpose: "Write a quote that reads like a decision document, not a price dump.",
		task: "Rewrite a typical proposal: situation, recommended path, options, rands, timeline, next step, validity. Short. No buzzword fog.",
		expected: "Proposal template in labelled sections, ~600 words."
	},
	{
		id: "agent-strategist",
		category: "agents",
		title: "AI Business Strategist",
		role: "managing partner",
		purpose: "Install a strategist agent that asks hard questions before giving advice.",
		task: "Write a system prompt for a business strategist agent: role, questions it must ask, SA context, refusal to invent numbers, and output format for weekly strategy.",
		expected: "Ready-to-paste system prompt + an example weekly brief.",
		featured: true
	},
	{
		id: "agent-content",
		category: "agents",
		title: "AI Content Strategist",
		role: "editorial director",
		purpose: "An agent that plans content from search and sales questions, not trends.",
		task: "Write a system prompt for a content strategist: pillars, local SEO, brand voice, and a weekly plan format. Ban engagement-bait.",
		expected: "System prompt + weekly plan schema."
	},
	{
		id: "agent-copy",
		category: "agents",
		title: "AI Sales Copywriter",
		role: "conversion copywriter",
		purpose: "A copywriter agent that stays specific and refuses fake urgency.",
		task: "Write a system prompt: audience, offer, proof rules, banned phrases, SA English, and a revision loop. No countdown timers unless they are real.",
		expected: "System prompt + a one-page critique rubric."
	},
	{
		id: "agent-ops",
		category: "agents",
		title: "AI Operations Manager",
		role: "operations manager",
		purpose: "Turn messy delivery into checklists and cadences.",
		task: "Write a system prompt for an ops manager agent: SOP drafting, bottleneck spotting, owner-run constraints, and a weekly ops review.",
		expected: "System prompt + ops review template."
	},
	{
		id: "agent-research",
		category: "agents",
		title: "AI Research Analyst",
		role: "research analyst",
		purpose: "Research that cites what it was given and flags what it was not.",
		task: "Write a system prompt: how to use pasted sources, how to mark uncertainty, never invent SA market stats, and a briefing format.",
		expected: "System prompt + research brief template."
	},
	{
		id: "agent-insights",
		category: "agents",
		title: "AI Customer Insights Agent",
		role: "insights lead",
		purpose: "Mine WhatsApp, reviews and calls (pasted, consented) for patterns.",
		task: "Write a system prompt that clusters customer language, jobs, and objections from pasted notes. Remind the user not to paste identity numbers or extra personal data.",
		expected: "System prompt, privacy reminder, and insight report format."
	},
	{
		id: "agent-pm",
		category: "agents",
		title: "AI Product Manager",
		role: "product manager",
		purpose: "Prioritise what to build or productise next.",
		task: "Write a system prompt for a PM agent: opportunity briefs, RICE-like scoring with honest unknowns, and a “do not build” list.",
		expected: "System prompt + opportunity one-pager."
	},
	{
		id: "agent-local-seo",
		category: "agents",
		title: "AI Local SEO Agent",
		role: "local SEO lead",
		purpose: "A specialist agent for GBP, pages, and near-me — without ranking promises.",
		task: "Write a system prompt: NAP, categories, reviews, landing pages, and a monthly local report that uses only metrics the owner can paste from GBP / Search Console.",
		expected: "System prompt + monthly report schema."
	},
	{
		id: "agent-popia",
		category: "agents",
		title: "AI Compliance Reviewer (POPIA-aware)",
		role: "privacy-aware editor",
		purpose: "Review marketing drafts for consent, over-collection, and reckless claims — not a substitute for legal advice.",
		task: "Write a system prompt that reviews copy for POPIA-sensitive issues and regulated claims, always stating it is not legal advice.",
		expected: "System prompt + a review checklist the owner still confirms with a professional when needed."
	},
	{
		id: "agent-desk",
		category: "agents",
		title: "AI Front-Desk Drafts",
		role: "front desk lead",
		purpose: "Draft replies a human still sends.",
		task: "Write a system prompt for drafting WhatsApp / email replies: tone, hours, booking, never inventing availability. Human sends the message.",
		expected: "System prompt + 8 example drafts."
	},
	{
		id: "agent-proposal",
		category: "agents",
		title: "AI Proposal Writer",
		role: "proposal lead",
		purpose: "Turn discovery notes into a draft proposal.",
		task: "Write a system prompt that consumes discovery notes and outputs a proposal in the house template. It must blank anything it was not told.",
		expected: "System prompt + proposal skeleton."
	},
	{
		id: "agent-prep",
		category: "agents",
		title: "AI Meeting Prep Agent",
		role: "chief of staff",
		purpose: "Walk into a meeting with a one-pager, not a panic.",
		task: "Write a system prompt: agenda, likely questions, numbers to verify, and a 5-line objective. Uses only pasted context.",
		expected: "System prompt + prep one-pager format."
	},
	{
		id: "agent-weekly",
		category: "agents",
		title: "AI Weekly Review Partner",
		role: "weekly review partner",
		purpose: "A Friday agent that turns the week into next week’s plan.",
		task: "Write a system prompt for a weekly review: wins, slips, pipeline, energy, and three commitments. No motivational posters.",
		expected: "System prompt + Friday review template."
	},
	{
		id: "workflow",
		category: "automation",
		title: "AI Automation Workflow Builder",
		role: "automation architect",
		purpose: "Design a workflow the owner can keep, with a human in the loop.",
		task: "Design one automation: trigger, steps, tools (generic), human checkpoints, failure states. Example: enquiry → WhatsApp → qualified → calendar. No tool lock-in.",
		expected: "Workflow blueprint, checkpoints, and a 1-week implementation order.",
		featured: true
	},
	{
		id: "brand-system",
		category: "automation",
		title: "Brand Voice System",
		role: "brand ops",
		purpose: "A repeatable way to run any draft through voice before it ships.",
		task: "Build a 6-step voice system: input, draft, voice pass, claim check, human edit, publish. Include the critique prompt.",
		expected: "System + critique prompt + examples of fail/pass."
	},
	{
		id: "social-ops",
		category: "automation",
		title: "Social Media Management OS",
		role: "social ops lead",
		purpose: "Run social as an operating system, not a daily panic.",
		task: "Design a monthly social OS: pillars, batching, approval, comments/WhatsApp handoff, and what not to automate.",
		expected: "Monthly OS, batch checklist, and a comment policy."
	},
	{
		id: "research-pipe",
		category: "automation",
		title: "Research Assistant Pipeline",
		role: "knowledge ops",
		purpose: "A pipeline from question → sources → brief → decision.",
		task: "Design a research pipeline with source-paste rules, uncertainty labels, and a 1-page brief. Ban invented citations.",
		expected: "Pipeline, brief template, and quality bar."
	},
	{
		id: "support-macros",
		category: "automation",
		title: "Customer Support Macro Library",
		role: "support lead",
		purpose: "Macros a human still sends, written in the house voice.",
		task: "Write 12 support macros: delay, invoice, complaint, refund request, after-hours, and “we need more info”. Tone: South African professional.",
		expected: "12 macros + when not to use a macro."
	},
	{
		id: "data-brief",
		category: "automation",
		title: "Data Analysis Brief",
		role: "analyst",
		purpose: "Ask AI to analyse only the numbers you paste.",
		task: "Write a brief template for pasted CSV / metrics: questions, definitions, and a rule that missing data stays missing. Example: GBP export or invoice list.",
		expected: "Analysis brief + sample questions + chart list (describe, don’t fake)."
	},
	{
		id: "intake",
		category: "automation",
		title: "Lead Intake → WhatsApp → Calendar",
		role: "revenue ops",
		purpose: "Stop losing the Monday enquiry in the chat list.",
		task: "Design intake: form or GBP → WhatsApp → qualify → book. Include after-hours, spam, and the human who owns exceptions.",
		expected: "Blueprint, scripts, and an exceptions list."
	},
	{
		id: "invoice-flow",
		category: "automation",
		title: "Invoice + Follow-up Flow",
		role: "finance ops",
		purpose: "Get paid without becoming a collections department.",
		task: "Design invoice issuance and a polite follow-up ladder in South Africa (EFT reality). No legal threats. Human checkpoint before any firm tone.",
		expected: "Timeline, message copy, and an escalation rule."
	},
	{
		id: "repurpose",
		category: "automation",
		title: "Content Repurposing Machine",
		role: "content ops",
		purpose: "One idea, many assets, one afternoon.",
		task: "Design a repurposing flow: long piece → LinkedIn, email, GBP post, WhatsApp broadcast (consented), and a short video script. Voice intact.",
		expected: "Flow, prompts per format, and a quality checklist."
	},
	{
		id: "loom-sop",
		category: "automation",
		title: "SOP from Loom Transcript",
		role: "documentation lead",
		purpose: "Turn a screen recording transcript into a SOP a stand-in could follow.",
		task: "Write a prompt that converts a pasted transcript into a SOP: purpose, steps, screenshots to add, failure points, and owner.",
		expected: "Conversion prompt + SOP template."
	},
	{
		id: "recipe",
		category: "automation",
		title: "Automation Recipe Designer",
		role: "solutions architect",
		purpose: "Describe Make/Zapier-style recipes without marrying a vendor.",
		task: "Propose 5 recipes for this business: trigger, steps, cost-of-failure, and whether a spreadsheet would do. Pick one to implement first.",
		expected: "5 recipes, a first pick, and a “don’t automate this” list."
	},
	{
		id: "hitl",
		category: "automation",
		title: "Human-in-the-loop QA Checklist",
		role: "quality lead",
		purpose: "Decide what AI may draft and what a human must sign.",
		task: "Build a QA checklist by content type: social, web, quotes, regulated advice, customer data. Clear stop rules.",
		expected: "Checklist table in prose and a wall-of-shame of things never to auto-send."
	},
	{
		id: "stack",
		category: "automation",
		title: "Tool Stack Simplifier",
		role: "IT-for-humans",
		purpose: "Cut tools until the stack fits an owner-run team.",
		task: "From a pasted tool list, recommend what to keep, combine, or drop. Prefer fewer tools. SA payment and WhatsApp reality.",
		expected: "Keep / drop / replace table and a 30-day simplification plan."
	},
	{
		id: "eisenhower",
		category: "decisions",
		title: "Eisenhower Matrix Week",
		role: "priority coach",
		purpose: "Sort the week so urgent noise does not eat the business.",
		task: "Run this week’s tasks through Eisenhower. Be ruthless about what is neither important nor urgent. Protect one deep-work block.",
		expected: "Four-quadrant plan and a calendar sketch."
	},
	{
		id: "rice",
		category: "decisions",
		title: "RICE Scoring Workshop",
		role: "prioritisation facilitator",
		purpose: "Score a backlog without fake precision.",
		task: "Facilitate RICE on 5–8 options. Use ranges where data is missing. Do not invent reach. Recommend a sequence.",
		expected: "Scored table in prose, assumptions, and a recommended order."
	},
	{
		id: "ooda",
		category: "decisions",
		title: "OODA Loop Decision",
		role: "decision coach",
		purpose: "Move a stuck decision through observe–orient–decide–act.",
		task: "Run OODA on the decision the owner names. Surface missing observations, bad orientation (imported advice), a decision, and a 7-day act.",
		expected: "OODA write-up and a 7-day action."
	},
	{
		id: "premortem",
		category: "decisions",
		title: "Pre-Mortem Analysis",
		role: "risk facilitator",
		purpose: "Imagine the project failed in 90 days — then prevent the obvious.",
		task: "Run a pre-mortem: 10 failure stories that could be true in South Africa (cash, load-shedding-adjacent ops, key person, a platform change). Then countermeasures.",
		expected: "Failure stories, likelihood (qualitative), and countermeasures.",
		featured: true
	},
	{
		id: "price-decision",
		category: "decisions",
		title: "Pricing Decision Brief",
		role: "commercial advisor",
		purpose: "Decide a price without a 40-tab spreadsheet fantasy.",
		task: "Write a pricing decision brief: costs you know, alternatives, willingness-to-pay evidence you actually have, and a recommended band in rands. Label guesses as guesses.",
		expected: "Brief, recommended band, and a 30-day test."
	},
	{
		id: "sunk",
		category: "decisions",
		title: "Sunk-Cost Interrogation",
		role: "decision coach",
		purpose: "Stop funding a dead offer because of last year’s effort.",
		task: "Interrogate a project the owner is reluctant to kill. Separate sunk cost from future return. Recommend continue / reshape / stop.",
		expected: "Interrogation, recommendation, and a dignified shutdown plan if needed."
	},
	{
		id: "launch-ready",
		category: "decisions",
		title: "Launch Readiness Check",
		role: "launch producer",
		purpose: "A go/no-go that cares about operations, not vibes.",
		task: "Score launch readiness: offer, page, fulfilment, payments, support, legal/POPIA, and owner calendar. No-go must be allowed.",
		expected: "Scorecard, blockers, and a go/no-go."
	},
	{
		id: "hire-ai",
		category: "decisions",
		title: "Hire vs Outsource vs AI",
		role: "org designer",
		purpose: "Pick the capacity move that matches the bottleneck.",
		task: "For a named bottleneck, compare hire, freelancer, and AI-assisted owner. Include cost-in-rands ranges as hypotheses and risk.",
		expected: "Comparison, recommendation, and a 14-day trial design."
	},
	{
		id: "opp-cost",
		category: "decisions",
		title: "Opportunity Cost Narrative",
		role: "advisor",
		purpose: "See what saying yes actually costs.",
		task: "For a tempting yes, write the opportunity cost: calendar, cash, reputation, and the project it would delay. Recommend yes/no.",
		expected: "Narrative, cost in time, and a recommendation."
	},
	{
		id: "meetings",
		category: "decisions",
		title: "Meeting Load Audit",
		role: "ops coach",
		purpose: "Cut meetings that do not decide anything.",
		task: "Audit a typical week of meetings/calls. Kill, shorten, or convert to WhatsApp/async. Protect delivery time.",
		expected: "Keep / kill / convert list and a meeting policy of 8 lines."
	},
	{
		id: "yes-no",
		category: "decisions",
		title: "Yes/No Filter for New Offers",
		role: "strategy filter",
		purpose: "A fast filter so not every idea becomes a new SKU.",
		task: "Build a 7-question yes/no filter for new offers. A single no should be allowed to kill it.",
		expected: "Filter, scoring, and 3 worked examples (generic)."
	},
	{
		id: "risk-reg",
		category: "decisions",
		title: "Practical Risk Register",
		role: "risk lead",
		purpose: "A living list, not a corporate PDF.",
		task: "Build a 10-line risk register for this business: cash, key person, platform, compliance, delivery. Owners and next review date.",
		expected: "Register in a simple table-in-prose."
	},
	{
		id: "journal",
		category: "decisions",
		title: "Decision Journal Template",
		role: "thinking partner",
		purpose: "Write the decision down so future-you can learn.",
		task: "Create a one-page decision journal: context, options, choice, expected signs, review date. Fill it for the current decision.",
		expected: "Filled journal + blank template."
	},
	{
		id: "skill-plan",
		category: "learning",
		title: "90-Day Skill Plan",
		role: "learning designer",
		purpose: "Learn one skill that unlocks revenue or time — not a course binge.",
		task: "Design a 90-day skill plan for the named skill: weekly practice, resources, and a demonstration of competence inside the business.",
		expected: "90-day plan, weekly drills, and a proof-of-skill project."
	},
	{
		id: "trends",
		category: "learning",
		title: "Trend Research Brief",
		role: "analyst",
		purpose: "Separate a real shift from a Twitter fad.",
		task: "Brief a trend: what would have to be true in South African service businesses for this to matter, leading indicators, and what to ignore.",
		expected: "Brief, watchlist, and a “not our problem” list."
	},
	{
		id: "case-decon",
		category: "learning",
		title: "Case Study Deconstruction",
		role: "strategy tutor",
		purpose: "Learn from someone else’s business without cargo-culting Silicon Valley.",
		task: "Deconstruct a pasted case (or a named public SA brand the user provides). What transfers to an owner-run service business, and what does not.",
		expected: "Transfer list, anti-transfer list, and 3 experiments."
	},
	{
		id: "sim",
		category: "learning",
		title: "Expert Simulation (role-play)",
		role: "role-play partner",
		purpose: "Practice a hard conversation before it is real.",
		task: "Role-play as a sceptical CFO, a late-paying client, or a prospect comparing two quotes. Stay in character, then debrief.",
		expected: "Role-play, debrief, and a better script."
	},
	{
		id: "tool-eval",
		category: "learning",
		title: "Tool Evaluation Scorecard",
		role: "procurement analyst",
		purpose: "Choose tools with a scorecard, not a demo hangover.",
		task: "Score 2–3 tools the user names: job-to-be-done, cost in rands, lock-in, POPIA/data, owner time to run. Recommend one or none.",
		expected: "Scorecard and a recommendation with kill-criteria."
	},
	{
		id: "sprint-learn",
		category: "learning",
		title: "Accelerated Learning Sprint",
		role: "learning coach",
		purpose: "A 14-day sprint to become dangerous enough to decide.",
		task: "Design a 14-day sprint: inputs, daily practice, what “good enough to decide” looks like, and a stop date.",
		expected: "14-day calendar and a decision test on day 14."
	},
	{
		id: "competitor-uni",
		category: "learning",
		title: "Competitor Content University",
		role: "competitive intelligence",
		purpose: "Study competitors as a curriculum, not an insecurity spiral.",
		task: "Build a 4-week study plan of 4 competitors’ public content. Extract patterns, gaps, and what not to copy.",
		expected: "Study plan, note template, and a gap list."
	},
	{
		id: "podcast-prep",
		category: "learning",
		title: "Podcast / Talk Prep",
		role: "comms coach",
		purpose: "Show up on a podcast or stage with 5 stories, not a brochure.",
		task: "Prep a 25-minute conversation: bio, 5 stories, 8 answers, and phrases that sound imported and should be cut.",
		expected: "One-pager, stories, and a bio of 80 words."
	},
	{
		id: "book-play",
		category: "learning",
		title: "Book-to-Playbook Distillation",
		role: "chief of staff",
		purpose: "Turn a business book into a 1-page playbook for this company.",
		task: "From a pasted outline or notes of a book, extract 7 operating rules that fit a South African owner-run service business. Discard the rest.",
		expected: "One-page playbook and a 30-day application plan."
	},
	{
		id: "mentor",
		category: "learning",
		title: "Mentorship Agenda",
		role: "mentee ops",
		purpose: "Stop wasting a mentor with updates they could read.",
		task: "Write a 45-minute mentor agenda: context pack sent in advance, 3 decisions, and notes format.",
		expected: "Pre-read template, agenda, and decision log."
	},
	{
		id: "cert",
		category: "learning",
		title: "Certification vs Practice",
		role: "career advisor",
		purpose: "Decide if a course is leverage or delay.",
		task: "For a named certification or course, argue practice vs paper. Recommend buy / wait / skip for this business.",
		expected: "Recommendation and an alternative practice plan."
	},
	{
		id: "teach",
		category: "learning",
		title: "Teaching-to-Learn Outline",
		role: "instructor",
		purpose: "Learn a topic by teaching it in a 20-minute internal session.",
		task: "Outline a 20-minute teach-back the owner could give the team or a peer. Include a demo in the business, not slides about theory.",
		expected: "Outline, demo, and 5 check questions."
	},
	{
		id: "weekly",
		category: "ops",
		title: "Weekly Planning Prompt",
		role: "chief of staff",
		purpose: "Plan a week an owner can finish, not a fantasy calendar.",
		task: "Build next week: 3 outcomes, delivery, sales, admin, rest. Put WhatsApp triage in a box. Protect one deep-work block. Load-shedding-aware only if the user says it matters this week.",
		expected: "A one-page week plan and a shutdown ritual.",
		featured: true
	},
	{
		id: "sop",
		category: "ops",
		title: "SOP Generator",
		role: "documentation lead",
		purpose: "Write a SOP a stand-in could follow on a Tuesday.",
		task: "Turn the named process into a SOP: purpose, owner, steps, tools, exceptions, and definition of done. Short sentences.",
		expected: "Full SOP plus a 5-line quick card.",
		featured: true
	},
	{
		id: "time-audit",
		category: "ops",
		title: "Time Audit",
		role: "productivity coach",
		purpose: "See where the hours actually went.",
		task: "From a pasted calendar or memory dump of a week, cluster time, name leaks, and propose a redesigned week that still delivers client work.",
		expected: "Clusters, leaks, and a redesigned week."
	},
	{
		id: "prioritise",
		category: "ops",
		title: "Task Prioritisation",
		role: "ops coach",
		purpose: "Rank today’s list by business effect, not inbox volume.",
		task: "Prioritise a pasted task list into: do now, schedule, delegate/AI-draft, drop. One must-win item.",
		expected: "Ranked list and a must-win."
	},
	{
		id: "os",
		category: "ops",
		title: "Personal Operating System",
		role: "operator coach",
		purpose: "Give the owner a light OS: capture, plan, do, review.",
		task: "Design a personal OS that fits WhatsApp-heavy work. Tools kept few. Include a Friday review.",
		expected: "OS diagram in prose, tools, and rituals."
	},
	{
		id: "wf-opt",
		category: "ops",
		title: "Workflow Optimisation",
		role: "process engineer",
		purpose: "Shorten a painful workflow without buying software first.",
		task: "Map the named workflow as-is, count handoffs, and propose a to-be with fewer steps. Software only if it is clearly cheaper than time.",
		expected: "As-is, to-be, and a 7-day change list."
	},
	{
		id: "agenda",
		category: "ops",
		title: "Meeting Agenda + Notes",
		role: "facilitator",
		purpose: "Every meeting ends with owners and dates.",
		task: "Write an agenda and a notes template. Default 25 minutes. No meeting without a decision or a date.",
		expected: "Agenda, notes template, and a cancellation rule."
	},
	{
		id: "handover",
		category: "ops",
		title: "Handover Document",
		role: "ops lead",
		purpose: "Hand work over so it does not bounce back in two days.",
		task: "Write a handover doc: context, status, files, next actions, risks, who to WhatsApp. Assume the reader is intelligent and busy.",
		expected: "Handover template filled from the user’s pasted context."
	},
	{
		id: "capacity",
		category: "ops",
		title: "Capacity Planning",
		role: "resource planner",
		purpose: "See how many jobs fit a month without heroics.",
		task: "Estimate monthly capacity from hours the owner actually has. Show what happens if two more clients say yes. Recommend a waitlist or a no.",
		expected: "Capacity picture, a yes/no rule, and a waitlist script."
	},
	{
		id: "triage",
		category: "ops",
		title: "Inbox / WhatsApp Triage",
		role: "comms operator",
		purpose: "Triage messages twice a day instead of living in the bubble.",
		task: "Design a triage protocol: batches, labels (now / later / ignore), canned starts, and a rule for after-hours.",
		expected: "Protocol, label set, and two batch windows."
	},
	{
		id: "q-review",
		category: "ops",
		title: "Quarterly Review",
		role: "strategy ops",
		purpose: "A quarterly review that changes the next 90 days.",
		task: "Run a quarterly review: numbers the owner can actually produce, offers, pipeline, energy, and 3 bets. Kill one thing.",
		expected: "Review memo and 3 bets + 1 kill."
	},
	{
		id: "shutdown",
		category: "ops",
		title: "End-of-Day Shutdown Ritual",
		role: "performance coach",
		purpose: "Close the laptop so the business does not follow the owner home.",
		task: "Write a 12-minute shutdown: capture, tomorrow’s top 3, WhatsApp status, and a hard stop. Realistic for a service business.",
		expected: "Checklist and a status-message option."
	},
	{
		id: "cadence",
		category: "ops",
		title: "Team Cadence Design",
		role: "team ops",
		purpose: "A cadence for a small team that is not enterprise theatre.",
		task: "Design weekly/monthly cadence for 2–8 people: stand-up or not, pipeline, delivery, and a monthly numbers chat. WhatsApp rules.",
		expected: "Cadence calendar and channel rules."
	},
	{
		id: "docs-habit",
		category: "ops",
		title: "Documentation Habit Builder",
		role: "knowledge manager",
		purpose: "Document as you go, 10 minutes at a time.",
		task: "Install a documentation habit: when to write, where it lives, and the 10-minute template. Start with the process that breaks when the owner is away.",
		expected: "Habit, template, and the first SOP to write."
	}
];
function buildPrompt(p) {
	return `ROLE
You are a senior operator and ${p.role}, working with a South African owner-run service business.

PURPOSE
${p.purpose}

BUSINESS CONTEXT (replace every bracket with verified facts — never invent)
- Business name: [BUSINESS NAME]
- Type / trade: [TYPE]
- Location: [CITY], [AREA]
- Ideal customer: [WHO THEY SERVE]
- Offer / price band in rands: [OFFER]
- Primary lead channel today: [WHATSAPP / GOOGLE / REFERRAL / OTHER]
- Current bottleneck: [BOTTLENECK]
- Constraint: [TIME / TEAM / BUDGET / COMPLIANCE]

TASK
${p.task}

RULES
- Use South African commercial context (rands, WhatsApp-first, local search, POPIA).
- Do not invent statistics, rankings, testimonials or legal advice.
- Flag anything that needs a qualified human (health, legal, financial, medical).
- End with: (1) the output asked for (2) 5 next actions the owner can take this week (3) what not to publish without review.

EXPECTED OUTPUT
${p.expected}`;
}
var featuredIds = [
	"avatar",
	"gap",
	"seo-map",
	"landing",
	"funnel",
	"agent-strategist",
	"workflow",
	"premortem",
	"sop",
	"weekly"
];
function getFeatured() {
	return featuredIds.map((id) => prompts.find((p) => p.id === id)).filter((p) => Boolean(p));
}
function promptsByCategory(id) {
	return prompts.filter((p) => p.category === id);
}
//#endregion
export { promptsByCategory as i, getFeatured as n, prompts as r, buildPrompt as t };
